use strict; use warnings;
print("input 5 number and then ctrl z");
my ($n1,$n2,$n3,$n4,$n5)=<STDIN>;
chomp($n1,$n2,$n3,$n4,$n5);
my @arr=();
if($n1%2==0){push(@arr,$n1)};
if($n2%2==0){push(@arr,$n2)};
if($n3%2==0){push(@arr,$n3)};
if($n4%2==0){push(@arr,$n4)};
if($n5%2==0){push(@arr,$n5)};
my @rev=reverse(@arr);
print("@rev");

