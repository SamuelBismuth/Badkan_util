#! usr/bin/perl
$age = <>;
print $age*2;


