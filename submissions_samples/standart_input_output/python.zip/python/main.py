var=input()
print("2\n3\n4")
